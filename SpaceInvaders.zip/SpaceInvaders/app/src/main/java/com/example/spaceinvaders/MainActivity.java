package com.example.spaceinvaders;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ImageView myImageView = findViewById(R.id.starship);
        myImageView.setImageResource (R.drawable.starship);

        RelativeLayout layout = findViewById(R.id.game_layout);
        for (int i = 0; i < 25; i++) {
            ImageView imagenInvader = new ImageView(this);
            Bitmap myBitMap = BitmapFactory.decodeResource(getResources(), R.drawable.invader);
            myBitMap = Bitmap.createScaledBitmap(myBitMap, 80, 80, true);
            imagenInvader.setImageBitmap(myBitMap);

            RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(80, 80);

            int row = i / 5;
            int col = i % 5;
            params.leftMargin = col * 100;
            params.topMargin = row * 100;

            layout.addView(imagenInvader, params);
        }
    }
}